mdct module
===========

.. automodule:: mdct
    :members:
    :undoc-members:
    :show-inheritance:
