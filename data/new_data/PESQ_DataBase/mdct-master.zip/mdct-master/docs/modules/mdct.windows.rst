mdct.windows module
===================

.. automodule:: mdct.windows
    :members:
    :undoc-members:
    :show-inheritance:
