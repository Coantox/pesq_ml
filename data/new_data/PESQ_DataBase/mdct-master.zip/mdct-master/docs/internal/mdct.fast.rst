mdct.fast module
================

.. automodule:: mdct.fast
    :members:
    :undoc-members:
    :show-inheritance:
